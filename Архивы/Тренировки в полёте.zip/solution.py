from flask import Flask, render_template, url_for

app = Flask(__name__)


@app.route('/training/<prof>')
def odd_even(prof):
    return render_template('index.html', p=prof, src=url_for('static', filename='img/ing.jpg'), alt='нет',
                           srcc=url_for('static', filename='img/stroy.jpg'), srccc=url_for('static', filename='img/ekip.jpg'))


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
