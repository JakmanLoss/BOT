from flask import Flask, render_template, url_for

app = Flask(__name__)


@app.route('/auto_answer')
@app.route('/answer')
def odd_even():
    user_dict = {'surname': "Watny", 'name': "Mark", 'education': "Выше среднего", "profession": "Штурман",
                 "sex": "male", "motivation": 'всегда мечтал застрять', "ready": "True"}
    return render_template('auto_answer.html', d=user_dict, h=url_for('static', filename='css/style.css'))


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
