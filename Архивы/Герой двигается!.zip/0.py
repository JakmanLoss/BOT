import pygame as py
import os


image = os.path.join('data', "1.png")
player_up = py.image.load(image)


WIDTH = 300
HEIGHT = 300
FPS = 60

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)


class Player(py.sprite.Sprite):
    def __init__(self):
        py.sprite.Sprite.__init__(self)
        self.image = player_up
        self.rect = self.image.get_rect()
        self.rect.centerx = WIDTH / 2
        self.rect.bottom = HEIGHT - 10
        self.rect.x = 0
        self.rect.y = 0

    def update(self):
        keystate = py.key.get_pressed()
        if keystate[py.K_a] or keystate[py.K_LEFT]:
            self.rect.x = self.rect.x - 1
        if keystate[py.K_d] or keystate[py.K_RIGHT]:
            self.rect.x = self.rect.x + 1
        if keystate[py.K_w] or keystate[py.K_UP]:
            self.rect.y = self.rect.y - 1
        if keystate[py.K_s] or keystate[py.K_DOWN]:
            self.rect.y = self.rect.y + 1


py.init()
py.mixer.init()
screen = py.display.set_mode((WIDTH, HEIGHT))
clock = py.time.Clock()

all_sprites = py.sprite.Group()
player = Player()
all_sprites.add(player)

running = True
while running:
    clock.tick(FPS)
    for event in py.event.get():
        if event.type == py.QUIT:
            running = False
    all_sprites.update()
    screen.fill(WHITE)
    all_sprites.draw(screen)
    py.display.flip()
py.quit()