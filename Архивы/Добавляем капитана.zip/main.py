from flask import Flask, session
from data import db_session
from data.users import User

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


def main():
    db_session.global_init("db/blogs.db")
    # app.run()


if __name__ == '__main__':
    main()


user = User()
user.surname = "Scott"
user.name = "Ridley"
user.age = 21
user.position = 'captain'
user.speciality = 'research engineer'
user.address = 'module_1'
user.email = "scott_chief@mars.org"
db_sess = db_session.create_session()
db_sess.add(user)
db_sess.commit()

user1 = User()
user1.surname = "Jane"
user1.name = "Jams"
user1.age = 18
user1.position = 'ingener'
user1.speciality = 'programm'
user1.address = 'module_2'
user1.email = "jane_jams@mars.org"
db_sess = db_session.create_session()
db_sess.add(user1)
db_sess.commit()

user2 = User()
user2.surname = "Maks"
user2.name = "Macs"
user2.age = 19
user2.position = 'doc'
user2.speciality = 'ing'
user2.address = 'module_3'
user2.email = "maks_macs@mars.org"
db_sess = db_session.create_session()
db_sess.add(user2)
db_sess.commit()

user3 = User()
user3.surname = "List"
user3.name = "Lest"
user3.age = 20
user3.position = 'prog'
user3.speciality = 'teach'
user3.address = 'module_4'
user3.email = "list_lest@mars.org"
db_sess = db_session.create_session()
db_sess.add(user3)
db_sess.commit()
