from flask import Flask, render_template

app = Flask(__name__)


@app.route('/index/<zag>')
def odd_even(zag):
    z = zag
    return render_template('odd_even.html', title=z)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')