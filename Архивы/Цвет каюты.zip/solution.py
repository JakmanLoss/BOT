from flask import Flask, redirect, render_template, url_for
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired

app = Flask(__name__)


@app.route('/table/<sex>/<age>')
def work(sex, age):
    return render_template('login.html', s=sex, a=int(age), h=url_for('static', filename='css/style.css'),
                           i=url_for('static', filename='img/boy_21.jpg'), ii=url_for('static', filename='img/in.jpg'),
                           iii=url_for('static', filename='img/in1.jpg'), mb=url_for('static', filename='img'
                                                                                                        '/whitblue.jpg'),
                           p=url_for('static', filename='img/pink.jpg'), red=url_for('static', filename='img/red.jpg'))


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
