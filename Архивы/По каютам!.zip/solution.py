from flask import Flask, redirect, render_template, url_for
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, BooleanField, SubmitField
from wtforms.validators import DataRequired

app = Flask(__name__)


@app.route('/distribution')
def work():
    return render_template('login.html')


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')
